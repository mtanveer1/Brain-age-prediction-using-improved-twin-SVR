function [PredictY,time]=iTSVR(TestX,DataTrain,FunPara)

tic;
c1 = FunPara.p1;
c2 = FunPara.p2;
c3 = FunPara.p3;
c4 = FunPara.p4;
eps1 = FunPara.p5;
eps2 = FunPara.p6;
kerfPara = FunPara.kerfPara;
A=DataTrain(:,1:end-1);
Y=DataTrain(:,end);

[samples, features]=size(A);
e=ones(samples,1);
kerfPara = FunPara.kerfPara;
AAt=A*A';
Q=[AAt+c3*eye(size(AAt)),AAt;AAt,AAt];
E=ones(size(Q));
QE=Q+E;
linQ1=c3*[-Y;-(Y+(eps1*e))];
bestalpha1=qpSOR(QE,0.3,c1,0.05,linQ1);
clear Q
linQ2=c4*[Y;Y-(eps2*e)];
bestalpha2=qpSOR(QE,0.3,c2,0.05,linQ2);
time=toc;
v1=-(1/c3)*[A',A';ones(1,2*size(A,1))]*bestalpha1;
v2=(1/c4)*[A',A';ones(1,2*size(A,1))]*bestalpha2;

e=ones(size(TestX,1),1);
m = size(v1,1);
Y1=TestX*v1(1:m-1)+v1(m)*e;
Y2=TestX*v2(1:m-1)+v2(m)*e;
DarwY.Y1 = Y1 - eps1;
DarwY.Y2 = Y2 + eps1;
PredictY=0.5*(Y1+Y2);
end