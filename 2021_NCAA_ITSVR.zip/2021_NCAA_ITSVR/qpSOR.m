function bestalpha=qpSOR(Q,t,C,smallvalue,fn)

[m,n]=size(Q);
alpha0=zeros(m,1);
mby2=m/2;
L=tril(Q);
E=diag(Q);
twinalpha=alpha0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute alpha
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:n
    %     i=i+1;
    twinalpha(j,1)=alpha0(j,1)-(t/E(j,1))*(Q(j,:)*twinalpha(:,1)-fn(j)+L(j,:)*(twinalpha(:,1)-alpha0));
    if j<mby2
        continue
    end
    if twinalpha(j,1)<0
        twinalpha(j,1)=0;
    elseif twinalpha(j,1)>C
        twinalpha(j,1)=C;
    else
        ;
    end
end
alpha=[alpha0,twinalpha];
while norm(alpha(:,2)-alpha(:,1))>smallvalue 
    %clc
     temp_norm=norm(alpha(:,2)-alpha(:,1));
    for j=1:n
        twinalpha(j,1)=alpha(j,2)-(t/E(j,1))*(Q(j,:)*twinalpha(:,1)-fn(j)+L(j,:)*(twinalpha(:,1)-alpha(:,2)));
        if j<mby2
            continue
        end
        if twinalpha(j,1)<0
            twinalpha(j,1)=0;
        elseif twinalpha(j,1)>C
            twinalpha(j,1)=C;
        else
            ;
        end
    end
    
    alpha(:,1)=[];
    alpha=[alpha,twinalpha];
    norm(alpha(:,2)-alpha(:,1));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Output
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
bestalpha=alpha(:,2);


