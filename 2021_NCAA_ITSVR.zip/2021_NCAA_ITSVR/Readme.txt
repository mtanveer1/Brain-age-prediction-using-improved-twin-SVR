The code corresponds to the paper "Brain age prediction using improved twin SVR" under revision in Neural Computing and Applications 2021.

If you are using our code, please give proper citation to the above given paper.

If there is any issue/bug in the code please write to phd1901141006@iiti.ac.in